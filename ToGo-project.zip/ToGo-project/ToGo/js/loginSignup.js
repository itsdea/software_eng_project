/*const firebaseApp = firebase.initializeApp({
    apiKey: "AIzaSyD3SN5sUnsXtKPg767fJmVUGBiiptzhm3Q",
    authDomain: "ameen-deliverfood.firebaseapp.com",
    projectId: "ameen-deliverfood",
    storageBucket: "ameen-deliverfood.appspot.com",
    messagingSenderId: "680822620289",
    appId: "1:680822620289:web:0adc2afa389a52aab7cd80",
    measurementId: "G-6YCVQ1XW4R"
});*/
// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-analytics.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, sendPasswordResetEmail, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDD0ekATqCcmfXls8jLSEp2RWGvjiAkEDY",
    authDomain: "togo-food-delivery-app.firebaseapp.com",
    projectId: "togo-food-delivery-app",
    storageBucket: "togo-food-delivery-app.appspot.com",
    messagingSenderId: "960964082159",
    appId: "1:960964082159:web:50f5dc7cfde5a60bbc5e1a",
    measurementId: "G-XG5KDQ7EW8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Show/Hide password functions remain the same

const validation = () => {
    let signUserName = document.getElementById('signUserName').value;
    let signUserPhone = document.getElementById('signUserPhone').value;
    let email = document.getElementById('signUserEmail').value;
    let pass = document.getElementById('signUserPass').value;
    let userSignupButton = document.getElementById('userSignupButton');

    if (signUserName && signUserPhone && email && pass) {
        userSignupButton.disabled = false;
    } else {
        userSignupButton.disabled = true;
    }
}

const resSignupValidation = () => {
    let signupResName = document.getElementById('signupResName').value;
    let signupResEmail = document.getElementById('signupResEmail').value;
    let signupResPassword = document.getElementById('signupResPassword').value;
    let file = document.getElementById('MainResImage').files[0];
    let resSignupButton = document.getElementById('resSignupButton');
    
    if (signupResName && signupResEmail && signupResPassword && file) {
        resSignupButton.disabled = false;
    } else {
        resSignupButton.disabled = true;
    }
}

const validationLogin = () => {
    let loginnameoremail = document.getElementById('loginnameoremail').value;
    let loginpassword = document.getElementById('loginpassword').value;
    let loginBtn = document.getElementById('loginBtn');
    if (loginnameoremail && loginpassword) {
        loginBtn.disabled = false;
    } else {
        loginBtn.disabled = true;
    }
}

const validationForget = () => {
    let forgetInput = document.getElementById('forgetInput').value;
    let sendForgetlinkBtn = document.getElementById('sendForgetlinkBtn');

    if (forgetInput.length === 0) {
        sendForgetlinkBtn.disabled = true;
    } else {
        sendForgetlinkBtn.disabled = false;
    }
}

// SignUp As User
const userSignUp = () => {
    let loader = document.getElementById('loader');
    loader.style.display = "block";
    let email = document.getElementById('signUserEmail').value;
    let pass = document.getElementById('signUserPass').value;
    let signUserName = document.getElementById('signUserName').value;

    createUserWithEmailAndPassword(auth, email, pass)
        .then((userCredential) => {
            var user = userCredential.user;
            console.log(user);
            updateProfile(user, {
                displayName: signUserName,
            });
            setUserInitialData(user);
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage);
            loader.style.display = "none";
            swal(errorMessage);
        });
}

const setUserInitialData = (user) => {
    let loader = document.getElementById('loader');
    let signUserName = document.getElementById('signUserName').value;
    let signUserPhone = document.getElementById('signUserPhone').value;
    let email = document.getElementById('signUserEmail').value;

    setDoc(doc(db, "users", user.uid), {
        email: email,
        name: signUserName,
        phoneNumber: signUserPhone,
        type: "user",
        userkey: user.uid,
    })
        .then(() => {
            console.log("Document successfully written!");
            window.location.href = "./index.html";
            loader.style.display = "none";
        })
        .catch((error) => {
            console.error("Error writing document: ", error);
            alert(error);
        });
}

// SignUp As Restaurant
const resturantSignUp = () => {
    let loader = document.getElementById('loader');
    loader.style.display = "block";
    let signupResEmail = document.getElementById('signupResEmail').value;
    let signupResPassword = document.getElementById('signupResPassword').value;

    createUserWithEmailAndPassword(auth, signupResEmail, signupResPassword)
        .then((userCredential) => {
            var resturant = userCredential.user;
            console.log(resturant);
            setresturantInitialData(resturant);
        })
        .catch((error) => {
            var errorMessage = error.message;
            console.log(errorMessage);
            loader.style.display = "none";
            swal(errorMessage);
        });
}

const setresturantInitialData = (resturant) => {
    let loader = document.getElementById('loader');
    let signupResName = document.getElementById('signupResName').value;
    let signupResEmail = document.getElementById('signupResEmail').value;

    setDoc(doc(db, "resturant", resturant.uid), {
        email: signupResEmail,
        name: signupResName,
        type: "resturant",
        restaurantkey: resturant.uid,
        imageurl: "",
        deal: "No deal",
        operorclose: "",
        wrkinghours: "",
        address: "",
        category: "",
        phonenumber: "",
        deliverycharges: "0",
    })
        .then(() => {
            console.log("Document successfully written!");
            loader.style.display = "none";
            uploadImageSignup(resturant);
        })
        .catch((error) => {
            console.error("Error writing document: ", error);
            loader.style.display = "none";
            swal(error);
        });
}

const login = () => {
    let loginnameoremail = document.getElementById('loginnameoremail').value;
    let loginpassword = document.getElementById('loginpassword').value;
    let loader = document.getElementById('loader');

    loader.style.display = "block";
    signInWithEmailAndPassword(auth, loginnameoremail, loginpassword)
        .then((userCredential) => {
            var user = userCredential.user;
            authStateListener();
        })
        .catch((error) => {
            var errorMessage = error.message;
            loader.style.display = "none";
            swal(errorMessage);
        });
}

const authStateListener = () => {
    let loader = document.getElementById('loader');
    onAuthStateChanged(auth, (user) => {
        if (user) {
            console.log(user.emailVerified);
            typeCheck(user);
        } else {
            console.log("no user");
        }
    });
}

const typeCheck = (user) => {
    let loader = document.getElementById('loader');
    getDoc(doc(db, "users", user.uid)).then((usersnapshot) => {
        if (!usersnapshot.exists()) {
            getDoc(doc(db, "resturant", user.uid)).then((ressnapshot) => {
                if (ressnapshot.exists() && ressnapshot.data().type == "resturant") {
                    window.location.href = "./resturantDash.html";
                    loader.style.display = "none";
                }
            });
        } else if (usersnapshot.data().type == "user") {
            window.location.href = "./userhome.html";
            loader.style.display = "none";
        }
    });
}

const logout = () => {
    let loader = document.getElementById('loader');
    loader.style.display = "block";
    signOut(auth).then(() => {
        console.log("Sign-out successful.");
        loader.style.display = "none";
        window.location.href = "./index.html";
    }).catch((error) => {
        console.log(error);
        loader.style.display = "none";
    });
}

const forgetpassword = () => {
    let loader = document.getElementById('loader');
    loader.style.display = "block";
    const email = document.getElementById('forgetInput').value;
    sendPasswordResetEmail(auth, email)
        .then(() => {
            console.log("Password reset email sent!");
            loader.style.display = "none";
            swal("Password reset email sent!");
            document.getElementById('forgetInput').value = "";
        })
        .catch((error) => {
            loader.style.display = "none";
            var errorMessage = error.message;
            console.log(errorMessage);
            swal(errorMessage);
        });
}

// Image upload
const uploadImageSignup = (res) => {
    let loader = document.getElementById('loader');
    loader.style.display = "block";
    const refStorage = ref(storage, 'resturantProfile/' + res.uid);
    let file = document.getElementById('MainResImage').files[0];
    const metadata = {
        contentType: file.type
    }
    uploadBytes(refStorage, file, metadata).then(snapshot => getDownloadURL(snapshot.ref))
        .then(url => {
            uploadImageFirestoreSignup(url, res);
            console.log(url);
            window.location.href = "./index.html";
            loader.style.display = "none";
        })
        .catch((err) => { console.log(err); swal(err) });
}

const uploadImageFirestoreSignup = (url, res) => {
    const resRef = doc(db, "resturant", res.uid);
    updateDoc(resRef, {
        imageurl: url
    })
        .then(() => {
            console.log("Document successfully updated!");
        })
        .catch((error) => {
            console.error("Error updating document: ", error);
            console.log(error);
        });


}
